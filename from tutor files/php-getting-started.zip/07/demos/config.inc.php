<?php
  define('MYSQL_HOST', 'localhost');
  define('MYSQL_USER', 'user');
  define('MYSQL_PASSWORD', 'password');
  define('MYSQL_DATABASE', 'php');
?>